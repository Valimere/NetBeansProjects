/*
 * CMSC350 Project 2 Stephen Drollinger Valimere@gmail.com DATE 11 December 2013
 * NetBeans IDE 7.4
 */

package Project2;

public interface IntSort {
    void sort(int [] array, int first, int last);
}
